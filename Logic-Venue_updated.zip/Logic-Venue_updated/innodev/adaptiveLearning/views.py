from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import EmailMessage
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import get_user_model
User = get_user_model()
from django.core.mail import send_mail
from django.conf import settings
# Create your views here.
from adaptiveLearning.models import profile, Addition
from django.views import View
from django.urls import reverse
from .utils import token_generator

from django.utils.encoding import force_bytes, force_text, DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.sites.shortcuts import get_current_site

def home(request):
    return render(request, 'home.html')


def topics(request):
    return render(request, 'topics.html')


def signup(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method == "POST":
        userN = request.POST.get("userName", "")
        try:
            pro = User.objects.get(username=userN)
            messages.info(request, 'User Name Already Taken')
            return redirect("home")
        except User.DoesNotExist:
            email = request.POST.get("email", "")
            passwor = request.POST.get("password", "")
            cpasswor = request.POST.get("cpassword", "")
            if passwor == cpasswor:
                p, created = User.objects.get_or_create(username=userN, email=email)
                p.set_password(passwor)
                p.is_active = True
                p.save()

                uidb64 = urlsafe_base64_encode(force_bytes(p.pk))
                domain = get_current_site(request).domain
                link = reverse('activate',kwargs={'uidb64': uidb64,'token': token_generator.make_token(p)})
                activate_url = 'http://'+domain+link
                email_subject = 'Activate Your Account'
                email_body = 'Hi '+p.username+' please use this link to verify your account\n'+ activate_url
                email = EmailMessage(
                    email_subject,
                    email_body,
                    'noreply@semicolon.com',
                    [email],
                )

                email.send(fail_silently=False)
                messages.info(request, 'Registration Successful! \n First Click on the link send on your mail to activate your account!')

                return redirect("home")
            else:
                messages.info(request, 'Password didn\'t Match')
                return redirect("home")
    return render(request, 'home.html')

class VerificationView(View):
    def get(self, request, uidb64, token):
        return redirect('home')

def Login(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method == "POST":
        uname = request.POST.get("loginuserName", "")
        paswo = request.POST.get("loginpass", "")
        user = authenticate(username = uname, password = paswo)
        if user is not None:
            login(request, user)
            return redirect("home")
        else:
            messages.info(request, 'Invalid Credentials!')
            return render(request, "home.html")
    return render(request, "home.html")

#def password_reset(request):
#    return render(request, 'password_reset.html')


def addition(request):
    qu = Addition.objects.get()
    return render(request, 'question_page.html', {'q': qu})


def index(request):
    return render(request, 'index.html')

def dashboard(request):
    return render(request, 'dashboard.html')
def attendance(request):
    return render(request, 'attendance.html')
def marks(request):
    return render(request, 'marks.html')
def timetable(request):
    return render(request, 'timetable.html')
def logout_request(request):
    logout(request)
    return redirect("home")