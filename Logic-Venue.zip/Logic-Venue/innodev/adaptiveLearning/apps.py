from django.apps import AppConfig


class AdaptivelearningConfig(AppConfig):
    name = 'adaptiveLearning'
