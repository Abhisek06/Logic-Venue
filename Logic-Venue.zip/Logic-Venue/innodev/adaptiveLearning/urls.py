from django.urls import path, include
from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('signup', views.signup, name='signup'),
    path('login', views.Login, name='login'),
    #path('password_reset', views.password_reset, name='password_reset'),
    path('addition', views.addition, name='addition'),
    path('index', views.index, name='index'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('logout', views.logout_request, name = "logout_request"),
    path('accounts/login/', views.home , name='home'),
]
